import mysql from './mysql/index.js';

const connection = mysql.createConnection({
    host: 'rds-latte-art-election.ckrcehmpvt3h.eu-west-3.rds.amazonaws.com',
    user: 'root',
    password: 'azertyui',
    database: 'latte-art-election'
});

export const handler = async (event) => {
    // Récupération des données du formulaire depuis l'événement Lambda
    const formData = JSON.parse(event.body);
    console.log("Prenom : " + formData.prenom);
    console.log("Nom : " + formData.nom);
    console.log("Choix : " + formData.choix);

    const prenom = formData.prenom;
    const nom = formData.nom;
    const choix = formData.choix;
    
    
    return new Promise((resolve, reject) => {       
        // Vérification si le couple prénom-nom existe déjà dans la table 'votes'
        const sqlCheck = `SELECT * FROM electeurs WHERE Electeur_prenom = '${prenom}' AND Electeur_nom = '${nom}'`;
        connection.query(sqlCheck, (error, results) => {
            if (error) {
                reject(error);
            } else{
                // Si le couple prénom-nom existe déjà
                if (results.length > 0) {
                    resolve(JSON.stringify("Oups... Vous avez déjà voté !"));
                } else {
                    // Récupération du nouvel ID de l'électeur
                    const sqlMaxId = "SELECT MAX(Id_electeur) AS max_id FROM electeurs";
                    console.log("nouvel id : "  + sqlMaxId);
                    connection.query(sqlMaxId, (errorMaxId, resultsMaxId) => {
                        if (errorMaxId) {
                            reject(error);
                        } else {
                            // Si pas de soucis incrémentation de l'id
                            const id = resultsMaxId[0].max_id + 1; 
                            // Ajout dans la table electeur le prénom et le nom du votant
                            const sqlInsertElecteur = `
                                INSERT INTO electeurs (Id_electeur, Electeur_nom, Electeur_prenom)
                                VALUES ('${id}', '${nom}', '${prenom}');
                            `;
                            // Ajout dans la table votes le nouveau vote
                            const sqlInsertVote = `
                                UPDATE votes
                                SET Nbr_de_vote = Nbr_de_vote + 1
                                WHERE Id_candidat = '${choix}';
                            `;
                            
                            //Renvoie d'une phrase indicative à l'utilisateur qui vient de voter
                            connection.query(sqlInsertElecteur, (errorInsertElecteur) => {
                                if (errorInsertElecteur) {
                                    reject(error);                                
                                } else {
                                    connection.query(sqlInsertVote, (errorInsertVote) => {
                                        if (errorInsertVote) {
                                            reject(error);                              
                                        } else {
                                            resolve(JSON.stringify('Votre vote a été comptabilisé, merci !'));
                                        }
                                    });
                                }
                            });
                         }
                    });
                }
            }
        });
    });
}