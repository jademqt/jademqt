declare const _exports: (obj: Record<PropertyKey, unknown>, property: PropertyKey, value: unknown, nonEnumerable?: boolean | null, nonWritable?: boolean | null, nonConfigurable?: boolean | null, loose?: boolean) => void;
export = _exports;
//# sourceMappingURL=index.d.ts.map