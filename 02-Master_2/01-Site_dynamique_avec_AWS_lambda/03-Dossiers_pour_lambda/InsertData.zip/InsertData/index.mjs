import mysql from './mysql/index.js';

const connection = mysql.createConnection({ 
        host: 'rds-latte-art-election.ckrcehmpvt3h.eu-west-3.rds.amazonaws.com',
        user: 'root',
        password: 'azertyui',
        database: 'latte-art-election'
});

export const handler = async (event) => {
    return new Promise((resolve, reject) => {
       const query = `
        SELECT 
            v.Id_candidat AS Choix,
            SUM(v.Nbr_de_vote) AS nb_votes,
            ROUND((SUM(v.Nbr_de_vote) * 100.0) / (SELECT SUM(Nbr_de_vote) FROM votes), 2) AS pourcentage,
            c.Prenom,
            c.Chemin_photo_latte,
            c.Id_candidat,
            c.Chemin_photo_profil,
            c.Presentation
        FROM votes v
        JOIN candidats c ON v.Id_candidat = c.Id_candidat
        GROUP BY v.Id_candidat
        ORDER BY pourcentage DESC;
    
        `;
    
        connection.query(query, (error, results) => {
            if (error) {
                reject(error);
            } else {
                resolve(JSON.stringify(results));
            }
        });
    });
}
